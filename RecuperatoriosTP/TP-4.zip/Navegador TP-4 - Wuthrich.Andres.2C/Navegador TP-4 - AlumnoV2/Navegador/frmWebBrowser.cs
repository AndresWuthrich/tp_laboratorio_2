﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Threading;
using Hilo;
using Archivos;

namespace Navegador
{
    public partial class frmWebBrowser : Form
    {
        private const string ESCRIBA_AQUI = "Escriba aquí...";
        Archivos.Texto archivos;

        #region Constructor
        public frmWebBrowser()
        {
            InitializeComponent();
        }
        #endregion

        private void frmWebBrowser_Load(object sender, EventArgs e)
        {
            this.txtUrl.SelectionStart = 0;  //This keeps the text
            this.txtUrl.SelectionLength = 0; //from being highlighted
            this.txtUrl.ForeColor = Color.Gray;
            this.txtUrl.Text = frmWebBrowser.ESCRIBA_AQUI;

            archivos = new Archivos.Texto(frmHistorial.ARCHIVO_HISTORIAL);
        }

        #region "Escriba aquí..."
        private void txtUrl_MouseMove(object sender, MouseEventArgs e)
        {
            Cursor.Current = Cursors.IBeam; //Without this the mouse pointer shows busy
        }

        private void txtUrl_KeyDown(object sender, KeyEventArgs e)
        {
            if (this.txtUrl.Text.Equals(frmWebBrowser.ESCRIBA_AQUI) == true)
            {
                this.txtUrl.Text = "";
                this.txtUrl.ForeColor = Color.Black;
            }
        }

        private void txtUrl_KeyUp(object sender, KeyEventArgs e)
        {
            if (this.txtUrl.Text.Equals(null) == true || this.txtUrl.Text.Equals("") == true)
            {
                this.txtUrl.Text = frmWebBrowser.ESCRIBA_AQUI;
                this.txtUrl.ForeColor = Color.Gray;
            }
        }

        private void txtUrl_MouseDown(object sender, MouseEventArgs e)
        {
            this.txtUrl.SelectAll();
        }
        #endregion

        delegate void ProgresoDescargaCallback(int progreso);
        private void ProgresoDescarga(int progreso)
        {
            if (statusStrip.InvokeRequired)
            {
                ProgresoDescargaCallback d = new ProgresoDescargaCallback(ProgresoDescarga);
                this.Invoke(d, new object[] { progreso });
            }
            else
            {
                tspbProgreso.Value = progreso;
            }
        }
        delegate void FinDescargaCallback(string html);
        private void FinDescarga(string html)
        {
            if (rtxtHtmlCode.InvokeRequired)
            {
                FinDescargaCallback d = new FinDescargaCallback(FinDescarga);
                this.Invoke(d, new object[] { html });
            }
            else
            {
                rtxtHtmlCode.Text = html;
            }
        }

        private void mostrarTodoElHistorialToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmHistorial f = new frmHistorial();

            //Invoca a historial
            f.ShowDialog();
       //     f.Close();
        }

        private void btnIr_Click(object sender, EventArgs e)
        {
            Archivos.Texto archivos = new Archivos.Texto(frmHistorial.ARCHIVO_HISTORIAL);
            Thread thread1 = new Thread(this.GuardarEnHistorico);
            // Guardo datos
            //try
            //{
            //    string datos = txtUrl.Text;
            //    archivos.guardar(datos);

            // //   ProgresoDescarga(50);
            //}
            //catch (Exception ie)
            //{
            //    MessageBox.Show(ie.Message);
            //}

            Thread thread2 = new Thread(this.DescargoUrl);
            //Barra de progreso
            //try
            //{
            //    Uri uri = new Uri(txtUrl.Text);
            //    Descargador descargador = new Descargador(uri);
            //    descargador.IniciarDescarga();
            //    descargador.DescargaCompleta += this.FinDescarga;
            //    descargador.ProgresoDescarga += this.ProgresoDescarga;
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}
            thread1.Start();
            thread2.Start();
        }
        private void GuardarEnHistorico()
        {
            Archivos.Texto archivos = new Archivos.Texto(frmHistorial.ARCHIVO_HISTORIAL);

            try
            {
                string datos = txtUrl.Text;
                archivos.guardar(datos);

                //   ProgresoDescarga(50);
            }
            catch (Exception ie)
            {
                MessageBox.Show(ie.Message);
            }
        }

        private void DescargoUrl()
        {
            try
            {
                Uri uri = new Uri(txtUrl.Text);
                Descargador descargador = new Descargador(uri);
                descargador.IniciarDescarga();
                descargador.DescargaCompleta += this.FinDescarga;
                descargador.ProgresoDescarga += this.ProgresoDescarga;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
