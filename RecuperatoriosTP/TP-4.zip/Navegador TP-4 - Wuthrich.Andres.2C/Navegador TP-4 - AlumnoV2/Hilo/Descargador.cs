﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Net; // Avisar del espacio de nombre
using System.ComponentModel;

namespace Hilo
{
    public class Descargador
    {
        private string html;
        private Uri direccion;

        #region Delegados y Eventos
        public delegate void DescargaCompletaEventHandler(string html);
        public event DescargaCompletaEventHandler DescargaCompleta;

        public delegate void ProgresoDescargaEventHandler(int progreso);
        public event ProgresoDescargaEventHandler ProgresoDescarga;
        #endregion

        #region Constructores
        public Descargador(Uri direccion)
        {
            this.html = "";
            this.direccion = direccion;
        }
        #endregion

        public void IniciarDescarga()
        {
            try
            {
                WebClient cliente = new WebClient();
//                cliente.DownloadProgressChanged += ;
                cliente.DownloadProgressChanged += WebClientDownloadProgressChanged;
//                cliente.DownloadStringCompleted += ;
                cliente.DownloadStringCompleted += WebClientDownloadCompleted;
                cliente.DownloadStringAsync(this.direccion);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        private void WebClientDownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            ProgresoDescarga(e.ProgressPercentage);
        }
        private void WebClientDownloadCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            DescargaCompleta(e.Result);
        }
    }
}
