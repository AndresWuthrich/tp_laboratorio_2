﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Archivos
{
    public class Texto : IArchivo<string>
    {
        string archivoConstructor;

        #region Constructores
        public Texto(string archivo)
        {
            this.archivoConstructor = archivo;
        }
        #endregion

        /// <summary>
        /// Serializo datos pasado por párametro. Guardo histórico
        /// </summary>
        public bool guardar(string datos)
        {
            System.IO.StreamWriter file = null;

            try
            {
                using (file = new System.IO.StreamWriter(this.archivoConstructor, true))
                {
                    file.WriteLine(datos);
                }
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
            finally
            {
                file.Close();               
            }
        }

        /// <summary>
        /// Deserializo archivo y lo guardo en la lista del parámetro.
        /// </summary>
        public bool leer(out List<string> datos)
        {
            System.IO.StreamReader file = null;
            datos = new List<string>();
            string datosXLinea;

            try
            {
                using (file = new System.IO.StreamReader(this.archivoConstructor))
                {
                    while ((datosXLinea = file.ReadLine()) != null)
                        datos.Add(datosXLinea);
                }
                return true;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                file.Close();
            }
        }
    }
}
