﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ClasesAbstractas;

namespace ClasesInstanciables
{
    public sealed class Profesor : Universitario
    {   
        Queue<Universidad.EClases> _clasesDelDia;
        static Random _random;

        #region "Constructores"
        public Profesor()
        { }
        static Profesor()
        {
            _random = new Random();            
        }
        public Profesor(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad)
            : base(id, nombre, apellido, dni, nacionalidad)
        {
            _clasesDelDia = new Queue<Universidad.EClases>();
            this.RandomClases();
        }
        #endregion

        #region "Operadores"

        /// <summary>
        /// Un Profesor será igual a un EClase si da esa clase.
        /// </summary>
        public static bool operator !=(Profesor i, Universidad.EClases clase)
        {
            return !(i == clase);
        }
        public static bool operator ==(Profesor i, Universidad.EClases clase)
        {
            if (i.Equals(i) && i.Equals(clase))
//            if (!object.ReferenceEquals(i, null) && !object.ReferenceEquals(clase, null))
            {
                foreach (Universidad.EClases c in i._clasesDelDia)
                {
                    if (clase == c)
                        return true;
                }
            }
            return false;
        }
        #endregion

        /// <summary>
        /// Asigno 2 clases al azar al profesor
        /// </summary>
        private void RandomClases()
        {
            int cantidad = 0, claseDelDia;

            do
            {
                claseDelDia=_random.Next(1, 4);

                switch(claseDelDia)
                {
                    case 1:
                        {
                            this._clasesDelDia.Enqueue(Universidad.EClases.Laboratorio);
                            break;
                        }
                    case 2:
                        {
                            this._clasesDelDia.Enqueue(Universidad.EClases.Legislacion);
                            break;
                        }
                    case 3:
                        {
                            this._clasesDelDia.Enqueue(Universidad.EClases.SPD);
                            break;
                        }
                    default:
                        {
                            this._clasesDelDia.Enqueue(Universidad.EClases.Programacion);
                            break;
                        }
                }
                cantidad++;
            } while (cantidad < 2);
        }

        /// <summary>
        /// Muestro clases que da el profesor
        /// </summary>
        protected override string ParticiparEnClase()
        {
            StringBuilder datos = new StringBuilder();
            datos.AppendLine("CLASES DEL DíA:");
            foreach (Universidad.EClases c in this._clasesDelDia)
            {
                datos.AppendLine(c.ToString());
            }
            return datos.ToString();
        }

        /// <summary>
        /// Muestro datos del profesor a través del método ToString
        /// </summary>
        protected override string MostrarDatos()
        {
            StringBuilder datos = new StringBuilder();
            datos.Append(base.MostrarDatos());
            datos.AppendLine(this.ParticiparEnClase());
            return datos.ToString();
        }

        public override string ToString()
        {
            return this.MostrarDatos(); 
        }
    }
}
