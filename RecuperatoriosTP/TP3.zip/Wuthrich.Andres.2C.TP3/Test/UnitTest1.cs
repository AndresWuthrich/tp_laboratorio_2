﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using ClasesAbstractas;
using Excepciones;
using ClasesInstanciables;

namespace Test
{
    [TestClass]
    public class UnitTest1
    {
        /// <summary>
        /// Nacionalidad invalida
        /// </summary>
        [TestMethod]
        public void Nacionalidad_Invalida()
        {
            string dniCero = "0";
            try
            {
                Alumno alumnoPrueba = new Alumno(5, "Carlos", "Gonzalez", dniCero, Persona.ENacionalidad.Argentino, 
                Universidad.EClases.Programacion, Alumno.EEstadoCuenta.AlDia);
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(NacionalidadInvalidaException));
                return;
            }
            Assert.Fail("Sin excepción para DNI inválido: {0}.", dniCero);
        }

        /// <summary>
        /// Dni invalido (con texto)
        /// </summary>
        [TestMethod]
        public void Dni_Invalido()
        {
            string dniTexto = "30a00123";
            try
            {
                Alumno alumnoPrueba = new Alumno(5, "Carlos", "Gonzalez", dniTexto, Persona.ENacionalidad.Argentino, 
                Universidad.EClases.Programacion, Alumno.EEstadoCuenta.AlDia);
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(DniInvalidoException));
            }
            Assert.Fail("Sin excepción para DNI inválido: {0}.", dniTexto);
        }

        /// <summary>
        /// Alumno repetido
        /// </summary>
        [TestMethod]
        public void Alumno_Repetido()
        {
            Universidad gim = new Universidad();

            Alumno a1 = new Alumno(1, "Juan", "Lopez", "12234456",
            ClasesAbstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Programacion,
            Alumno.EEstadoCuenta.Becado);
            gim += a1;
            try
            {
                Alumno a3 = new Alumno(3, "José", "Gutierrez", "12234456",
                ClasesAbstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Programacion,
                Alumno.EEstadoCuenta.Becado);
                gim += a3;
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(AlumnoRepetidoException));
            }
        }

        /// <summary>
        /// Valor nulo
        /// </summary>
        [TestMethod]
        public void Valor_Nulo()
        {
            Universidad gim = new Universidad();

            try
            {
                Profesor i1 = new Profesor(1, "Juan", "Lopez", "12234456", Persona.ENacionalidad.Argentino);
                gim += i1;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
