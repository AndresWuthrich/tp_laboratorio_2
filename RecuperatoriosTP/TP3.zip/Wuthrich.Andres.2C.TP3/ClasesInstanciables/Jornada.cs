﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Archivos;
using ClasesAbstractas;

namespace ClasesInstanciables
{
    public class Jornada
    {
        List<Alumno> _alumnos;
        Universidad.EClases _clase;
        Profesor _instructor;

        #region "Constructores"
        private Jornada()
        {
            _alumnos = new List<Alumno>();
        }
        public Jornada(Universidad.EClases clase, Profesor instructor):this()
        {
            this._clase = clase;
            this._instructor = instructor;
        }
        #endregion

        #region "Propiedades"
        public List<Alumno> Alumnos
        {
            get
            { return this._alumnos; }
            set
            { this._alumnos = value; }
        }
        public Universidad.EClases Clase
        {
            get
            { return this._clase; }
            set
            { this._clase = value; }
        }
        public Profesor Instructor
        {
            get
            { return this._instructor; }
            set
            { this._instructor = value; }
        }
        #endregion

        #region "Operadores"
        /// <summary>
        /// Una Jornada será igual a un alumno si el mismo participa de la clase.
        /// </summary>
        public static bool operator !=(Jornada j, Alumno a)
        {
            return !(j == a);
        }
        public static bool operator ==(Jornada j, Alumno a)
        {
            // Controlo que ni alumno ni clase no hayan sido instanciados, para evitar errores.
            if (j.Equals(j) && a.Equals(a))
            //if (!object.ReferenceEquals(j, null) && !object.ReferenceEquals(a, null))
            {
                foreach (Alumno alumno in j._alumnos)
                {
                    // Busco alumno en la clase.
                    if (a == alumno)
                        return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Agrega alumnos a la clase, siempre y cuando no estén previamente cargados.
        /// </summary>
        public static Jornada operator +(Jornada j, Alumno a)
        {
            if(j != a)
                j._alumnos.Add(a);
            
            return j;
        }
        #endregion

        /// <summary>
        /// Guardo jornada en archivo de texto
        /// </summary>
        public static bool Guardar(Jornada jornada)
        {
            Texto txt = new Texto();
            txt.Guardar("Jornada.txt", jornada.ToString());

            return true;
        }

        /// <summary>
        /// Leo archivo de texto
        /// </summary>
        public static string Leer()
        {
            Texto txt = new Texto();
            string datos;
            txt.Leer("Jornada.txt", out datos);
            return datos; 
        }

        /// <summary>
        /// Muestro datos de la jornada
        /// </summary>
        public override string ToString()
        {
            StringBuilder datos = new StringBuilder();
            datos.AppendLine("CLASE DE "+ this.Clase + " POR " + this.Instructor);
            datos.AppendLine("ALUMNOS:");
            foreach (Alumno a in this._alumnos)
            {
                datos.Append(a.ToString());
            }
            datos.AppendLine("<------------------------------------------------->");
            return datos.ToString();
        }
    }
}
