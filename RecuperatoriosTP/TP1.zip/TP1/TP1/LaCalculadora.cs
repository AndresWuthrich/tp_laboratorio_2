﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Entidades; 

namespace TP1
{
    public partial class LaCalculadora : Form
    {
        public LaCalculadora()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Cargo Calculadora
        /// </summary>
        private void LaCalculadora_Load(object sender, EventArgs e)
        { }

        /// <summary>
        /// Boton Cerrar cierra formulario
        /// </summary>
        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Boton Limpiar llama Limpiar
        /// </summary>
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        /// <summary>
        /// Boton ConvertirABinario llama DecimalBinario
        /// </summary>
        private void btnConvertirABinario_Click(object sender, EventArgs e)
        {
            lblResultado.Text = Numero.DecimalBinario(lblResultado.Text);
        }

        /// <summary>
        /// Boton ConvertirADecimal llama BinarioDecimal
        /// </summary>
        private void btnConvertirADecimal_Click(object sender, EventArgs e)
        {
            lblResultado.Text = Numero.BinarioDecimal(lblResultado.Text);            
        }

        /// <summary>
        /// Boton Operar llama a Operar con datos por pantalla. Devuelve resultado a pantalla.
        /// </summary>
        private void btnOperar_Click(object sender, EventArgs e)
        {
            double resultado = Operar(txtNumero1.Text, txtNumero2.Text, cmbOperador.Text);

            lblResultado.Text = resultado.ToString(); 
        }

        /// <summary>
        /// Limpio campos en pantalla
        /// </summary>
        private void Limpiar()
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            cmbOperador.Text = " ";
            lblResultado.Text = "0";
        }

        /// <summary>
        /// Operar llama a Operar de Calculadora 
        /// </summary>
        private static double Operar(string numero1, string numero2, string operador)
        {
            Numero nro1 = new Numero(numero1);
            Numero nro2 = new Numero(numero2);
            return Calculadora.Operar(nro1, nro2, operador);
        }
    }
}
