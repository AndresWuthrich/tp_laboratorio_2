﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    /// <summary>
    /// Enumerador de operaciones (sin uso)
    /// </summary>
    public enum Operacion
    { Suma, Resta, Multiplicacion, Division }

    public class Calculadora
    {
        /// <summary>
        /// Resuelvo operaciones
        /// </summary>
        public static double Operar(Numero numero1, Numero numero2, string operador)
        {
            //Valido operacion
            string validoOper = validarOperador(operador);
                                   
            double resultado = 0;
            
            switch (validoOper)
            {
                case "-": //Operacion.Resta:
                    resultado = (numero1 - numero2);
                    break;
                case "*": //Operacion.Multiplicacion:
                    resultado = (numero1 * numero2);
                    break;
                case "/": //Operacion.Division:
                    resultado = (numero1 / numero2);
                    break;
                default: //Operacion.Suma:
                    resultado = (numero1 + numero2);
                    break;
            }
            return resultado;
        }

        /// <summary>
        /// Valido operador
        /// </summary>
        private static string validarOperador(string operador)
        {
            if (operador != "+" && operador != "-" && operador != "*" && operador != "/")
            {
                return "+";
            }
            else
            {
                return operador;
            }
        }
    }
}
