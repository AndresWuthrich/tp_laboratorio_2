﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Numero
    {
        double numero;

        #region "Constructores"
        public Numero()
        {
            this.numero = 0;
        }
        public Numero(double numero)
        {
            this.numero = numero;
        }
        public Numero(string strNumero)
        {
            this.SetNumero = strNumero;  
        }
        #endregion

        #region "Propiedades"
        private string SetNumero
        {
            set
            { this.numero = validarNumero(value); }
        }
        #endregion

        #region "Operadores"
        public static double operator -(Numero n1, Numero n2)
        {
            double resultado = n1.numero - n2.numero;
            return resultado;
        }
        public static double operator *(Numero n1, Numero n2)
        {
            double resultado = n1.numero * n2.numero;
            return resultado;
        }
        public static double operator /(Numero n1, Numero n2)
        {            
            //valido divisor = 0
            if (n2.numero == 0)
                return 0;
 
            double resultado = n1.numero / n2.numero;
            return resultado;
        }
        public static double operator +(Numero n1, Numero n2)
        {
            double resultado = n1.numero + n2.numero;
            return resultado;
        }
        #endregion

        /// <summary>
        /// Valido números
        /// </summary>
        private static double validarNumero(string strNumero)
        {
            double numero;
            if(double.TryParse(strNumero, out numero))
                 return numero;
            return 0;
        }

        /// <summary>
        /// Convierto binario a decimal
        /// </summary>
        public static string BinarioDecimal(string binario)
        {
            string respuesta = "Valor inválido";
            int nroDecimal = 0;

            for (int i = 1; i <= binario.Length; i++)
            {  
                nroDecimal += int.Parse(binario[i - 1].ToString()) * (int)Math.Pow(2, binario.Length - i);
            }
            if (nroDecimal != 0)
                return nroDecimal.ToString();
            return respuesta; 
        }

        /// <summary>
        /// Convierto decimal(double) a binario
        /// </summary>
        public static string DecimalBinario(double numero)
        {
            string binario = "", respuesta = "Valor inválido";

            do
            {
                if((numero % 2)== 0)
                    binario="0"+ binario;
                else
                    binario="1"+ binario;
                numero=(int)(numero/2);
            }while(numero > 0 );

            if (binario != "")
                return binario;
            return respuesta;
        }
        /// <summary>
        /// Convierto decimal(string) a binario, llamo a DecimalBinario (double)
        /// </summary>
        public static string DecimalBinario(string numero)
        {
            string binario = "", respuesta = "Valor inválido";
            
            double numeroDouble = 0;
            if (double.TryParse(numero, out numeroDouble))
                binario = DecimalBinario(numeroDouble);

            if (binario != "")
                return binario;
            return respuesta;
        }
    }
}
